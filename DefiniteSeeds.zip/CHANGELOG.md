# 1.1.2

Fixed incorrect icon

Removed extraneous functions (moved to SeedSearcher mod)

# 1.1.1

Update for AtO v1.7.2

Allowed EnableMod to turn off the mod without restart

# 1.1.0

Added ability to search from menu

# 1.0.2

Added ability to search for a single seed (backend)

# 1.0.1

Added back-end searching for boss/guaranteed items

# 1.0.0

Initial Release